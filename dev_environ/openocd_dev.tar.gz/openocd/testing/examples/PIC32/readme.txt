Here you'll find a simple example tested with PIC32 Starter kit (source code and .elf file). It will blink repeatedly the LEDs on the board.
The program was compiled and written on the target using MPLAB IDE v 8.0 that comes with the kit because openocd is missing currently the ability
to program the flash for this specific target. It is possible in the future this limitation to be removed.
